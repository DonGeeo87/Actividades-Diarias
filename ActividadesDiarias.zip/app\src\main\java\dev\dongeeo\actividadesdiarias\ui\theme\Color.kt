package dev.dongeeo.actividadesdiarias.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF4A90E2)
val MintSecondary = Color(0xFF50E3C2)
val BackgroundLight = Color(0xFFF9FAFB)
val TextPrimary = Color(0xFF1A1A1A)
val TextSecondary = Color(0xFF6B7280)
val AccentLight = Color(0xFFE0E7FF)


