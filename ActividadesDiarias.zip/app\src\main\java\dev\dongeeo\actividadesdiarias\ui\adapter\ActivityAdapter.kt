package dev.dongeeo.actividadesdiarias.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import dev.dongeeo.actividadesdiarias.databinding.ItemActivityBinding
import dev.dongeeo.actividadesdiarias.model.ActivityItem

class ActivityAdapter : ListAdapter<ActivityItem, ActivityAdapter.ActivityViewHolder>(Diff) {

    object Diff : DiffUtil.ItemCallback<ActivityItem>() {
        override fun areItemsTheSame(oldItem: ActivityItem, newItem: ActivityItem): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: ActivityItem, newItem: ActivityItem): Boolean =
            oldItem == newItem
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ActivityViewHolder {
        val binding = ItemActivityBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ActivityViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ActivityViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ActivityViewHolder(private val binding: ItemActivityBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: ActivityItem) = with(binding) {
            tvTitle.text = item.title
            tvDate.text = "${item.date} · ${item.time}"
            tvDescription.text = item.description.ifEmpty { "Sin descripción" }
            tvDescription.visibility = if (item.description.isEmpty()) View.GONE else View.VISIBLE
        }
    }
}

